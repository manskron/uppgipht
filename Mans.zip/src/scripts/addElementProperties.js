function addElementProperties() {}

export default addElementProperties;
