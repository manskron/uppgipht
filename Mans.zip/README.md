# uppgipht

A minimal todo app written in vanilla Javascript

### Light theme
![Light theme](screenshots/light.png)
### Dark Theme
![Dark theme](screenshots/dark.png)
